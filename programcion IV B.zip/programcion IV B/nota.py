#dayana jerez
#mañana es abril

# 31-03-2025


nota = 40

if nota >= 40:
    print('tu pasaste')
    
else:
   print('tu pasaste')