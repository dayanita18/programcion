#conocer que los elementos en una 
#tupla tienen indices que comienzan en 0

tupla = ("A","B","c")

print(tupla[0])
print(tupla[1])
print(tupla[2])