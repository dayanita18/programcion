#creacion de tuplas:
#saber como definir una tupla utilizando parentesis()

tupla = ("elementos1","elemento2","elemento3")

print(tupla)