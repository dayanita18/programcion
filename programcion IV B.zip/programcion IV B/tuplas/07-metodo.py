#metodo de las tuplas

#index( ): encontrar la posicion de un elemento


tupla("a","b","c")

print(tupla.index("a"))


#count(): cuenta cuantas veces aparece un elememto en 

print(tupla.count("c"))        