
#sacar dinero del banco

print(tareas[0])

#ver mi heroe academia

print(tareas[-1])

# ['dar un paseo.','caortarse el cabello.' ,'preparar un te.']

print[tareas2:5]