#dayana jerez
#tengo sueño
#25-03-2025


peso = 54

altura = 1.53

imc = peso / (altura ** 2)

print(imc )