#verificar la existencia de un elemento (in):

#saber usar el operador in para comprobar si
#elemento esta presente en una tupla 

tupla =("python","java","c++")

print("java" in tupla)