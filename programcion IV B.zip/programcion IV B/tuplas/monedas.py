# dayana jerez
# soy millonaria
# 25-03-2025


pesos = int(input("cuanto te queda en pesos colombianos?"))
soles = int(input("cuanto te queda en soles peruanos?"))
reales= int(input("cuanto te queda en reales brasil?"))

total = pesos * 0.00025 + soles * 0.28 + reales * 0.21
 
print(total)
