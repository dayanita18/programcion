#desempaquetar la tupla

#entender como se asigna
#los valores de una tupla a variables 

tuplas = (10,20,30)
a,b,c,= tuplas

print(a,b,c)