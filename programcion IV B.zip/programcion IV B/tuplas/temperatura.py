#dayana jerez
#tengo un gato
#25-03-2025

temp_f = 59

temp_c = ( temp_f - 32) /1.8

print(temp_c )
