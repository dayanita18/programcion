

#dayana jerez
#02-04-2025


usuario = input('ingresare tu nombre')
hambre = int(input('¿cuanta hambre tienes? (1-10)'))
enojo = int(input('cuanto enojo tienes? (1-10)'))

if hambre > 4 and enojo >1:
    print('enfadado por hambre')