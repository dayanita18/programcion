#dayana jerez 10-03-2025
print("       1")
print("     2 3" )          
print("   4 5 6")       
print("7 8 9 10")