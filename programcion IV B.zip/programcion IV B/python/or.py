

#dayana jerez
#02-04-2025
#es miercoles y salgo alas 1:45

print("!bienvenido a tu dia feliz")

cafe = int(input('¿cuantas tazas de cafe has tomas hoy (0 o mas)'))
te_burbujas = int(input('¿cuantas tazas de te burbujas haz tomado hoy'))

if cafe >0 or te_burbujas >0:
    print('¡que bien! has disfrutado algo rico hoy')
else : 
    print('parece que no has tomado nada especial hoy. ¡animate!')