#dayana jerez
#02-04-2025

respuesta = input('¿estas cansado? (si/no):').strip().lower()

cansado = respuesta == 'si'

if not cansado:
    print('!es horaa de programar')
    
else:
    print('tomate un descanso,lo necesitas')