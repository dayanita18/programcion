# dayana jerez
#31-03-2025

nota= 70

if nota > 70 :
    print('paso yuju!!!')
elif nota > 60:
    print('paso')
elif nota > 50:
    print('nota es nota')
elif nota > 40 :
    print('vas po un buen camino')
else:
    print('no te rindas,cada error continua')